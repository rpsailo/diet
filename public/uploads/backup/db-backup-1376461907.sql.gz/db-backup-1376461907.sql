DROP TABLE IF EXISTS backup;

CREATE TABLE `backup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `file` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO backup VALUES("16","/uploads/backup/db-backup-1376319500.sql.gz","2013-08-12 20:28:20","2013-08-12 20:28:20");
INSERT INTO backup VALUES("17","/uploads/backup/db-backup-1376319557.sql.gz","2013-08-12 20:29:17","2013-08-12 20:29:17");
INSERT INTO backup VALUES("18","/uploads/backup/db-backup-1376398563.sql.gz","2013-08-13 18:26:03","2013-08-13 18:26:03");
INSERT INTO backup VALUES("19","/uploads/backup/db-backup-1376412461.sql.gz","2013-08-13 22:17:41","2013-08-13 22:17:41");



DROP TABLE IF EXISTS program;

CREATE TABLE `program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `duration` int(45) DEFAULT NULL,
  `target` varchar(200) DEFAULT NULL,
  `objectives` text,
  `no_of_intake` int(11) DEFAULT NULL,
  `faculties` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO program VALUES("3","Programme 3","20","Target One","Objec","200","2","1","2013-06-19 20:06:12","2013-07-20 21:16:42");
INSERT INTO program VALUES("4","Program 4","20","Target One","asdas","10","5,3,4","1","2013-06-19 20:10:20","2013-08-13 14:42:42");



DROP TABLE IF EXISTS school;

CREATE TABLE `school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `address` text,
  `district` varchar(200) DEFAULT NULL,
  `sub_division` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `year_of_establishment` int(4) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL COMMENT 'Adhoc, Aided, Govt. etc.',
  `level` varchar(250) DEFAULT NULL,
  `no_of_teachers` int(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO school VALUES("3","College Veng Govt Middle School","Serkawn, Lunglei, Mizoram","Lunglei","Hnahthial Sub Division","9436542329","1975","Govt","Middle School","120","1","2013-06-19 09:31:43","2013-08-13 12:55:26");
INSERT INTO school VALUES("4","Govt Middle School, Tlangnuam","Tlangnuam, Aizawl","Kolasib","Kolasib Block","9763546253","1986","Adhoc Aided","Middle School","200","1","2013-06-19 09:33:00","2013-07-20 20:55:29");
INSERT INTO school VALUES("5","Ramthar Government Primary School","Ramthar, Aizawl","Kolasib","Kolasib Block","1273879797","1985","Deficit","Primary School","200","1","2013-06-19 09:33:00","2013-07-20 20:55:43");
INSERT INTO school VALUES("6","Republic Primary School","Ramthar","Kolasib","Serchhip Block","961911111","1987","Govt","Primary School","100","1","2013-06-25 21:21:40","2013-07-20 20:55:51");
INSERT INTO school VALUES("7","Zotlang PS","Zotlang","Aizawl","Aizawl East Sub Division","9612800483","1975","Govt","Primary School","12","1","2013-08-13 12:06:05","2013-08-13 12:06:05");



DROP TABLE IF EXISTS school_statistic;

CREATE TABLE `school_statistic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) NOT NULL,
  `boys_1` int(6) NOT NULL,
  `girls_1` int(6) NOT NULL,
  `boys_2` int(6) NOT NULL,
  `girls_2` int(6) NOT NULL,
  `boys_3` int(6) NOT NULL,
  `girls_3` int(6) NOT NULL,
  `boys_4` int(6) NOT NULL,
  `girls_4` int(6) NOT NULL,
  `boys_5` int(6) NOT NULL,
  `girls_5` int(6) NOT NULL,
  `boys_6` int(6) NOT NULL,
  `girls_6` int(6) NOT NULL,
  `boys_7` int(6) NOT NULL,
  `girls_7` int(6) NOT NULL,
  `boys_8` int(6) NOT NULL,
  `girls_8` int(6) NOT NULL,
  `year` int(4) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO school_statistic VALUES("7","4","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2013","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("8","5","2000","544","87","11","23","20","44","446","0","20","201","287","23","2","0","0","2013","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("9","6","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2013","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("10","3","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2012","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("11","4","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2012","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("12","5","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2012","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("13","6","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2012","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("14","3","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2011","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("15","4","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2011","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("16","5","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2011","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("17","6","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2011","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("18","3","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2010","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("19","4","0","0","0","0","0","0","0","0","90","100","11","12","13","14","150","160","2010","2013-07-06 21:47:02","2013-07-15 19:58:54");
INSERT INTO school_statistic VALUES("20","5","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2010","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("21","6","10","101","11","6","5","76","44","446","0","0","0","0","0","0","0","0","2010","2013-07-15 20:56:18","2013-07-15 20:56:18");
INSERT INTO school_statistic VALUES("23","3","0","0","0","0","0","0","0","0","7","8","7","56","57","43","66","18","2001","2013-07-15 22:49:49","2013-07-15 22:49:49");



DROP TABLE IF EXISTS sub_division_block;

CREATE TABLE `sub_division_block` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `district` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO sub_division_block VALUES("1","Aizawl East Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("2","Aizawl West Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("3","Aizawl South Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("4","Lungsen Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("5","Darlawn Sub Division","");
INSERT INTO sub_division_block VALUES("6","Saitual Sub Division","");
INSERT INTO sub_division_block VALUES("7","Lunglei North Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("8","Lunglei South Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("9","Hnahthial Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("10","Serchhip Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("11","North Vanlaiphai Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("12","Thenzawl Sub Division","");
INSERT INTO sub_division_block VALUES("13","Saiha Block","Saiha");
INSERT INTO sub_division_block VALUES("14","Tuipang Block","Serchhip");
INSERT INTO sub_division_block VALUES("15","Bungtlang South Block","");
INSERT INTO sub_division_block VALUES("16","Sangau Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("17","Chawngte Block","");
INSERT INTO sub_division_block VALUES("18","Bualpui N  Sub Division","");
INSERT INTO sub_division_block VALUES("19","Lawngtlai Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("20","Champhai Block","Champhai");
INSERT INTO sub_division_block VALUES("21","Khawbung Block","");
INSERT INTO sub_division_block VALUES("22","Khawzawl Block","");
INSERT INTO sub_division_block VALUES("23","Ngopa Block","Champhai");
INSERT INTO sub_division_block VALUES("24","Mamit Sub Division","Mamit");
INSERT INTO sub_division_block VALUES("25","Kawrthah Sub Division","");
INSERT INTO sub_division_block VALUES("26","West Phaileng Sub Division","");
INSERT INTO sub_division_block VALUES("27","Kolasib Block","Kolasib");
INSERT INTO sub_division_block VALUES("28","Kawnpui Block","");



DROP TABLE IF EXISTS teacher;

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `sex` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `present_address` text,
  `permanent_address` text,
  `district` varchar(200) DEFAULT NULL,
  `sub_division` varchar(200) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `educational_qualification` varchar(200) DEFAULT NULL,
  `professional_qualification` varchar(200) DEFAULT NULL,
  `other_qualification` varchar(45) DEFAULT NULL COMMENT 'Yes or No. Trained or Not trained.',
  `year_of_retirement` int(4) DEFAULT NULL,
  `tet` varchar(10) DEFAULT NULL COMMENT 'Teacher Eligibility Test',
  `main_subject_taught` varchar(200) DEFAULT NULL,
  `achievement` text,
  `training_attended` varchar(3) NOT NULL DEFAULT 'No',
  `no_of_training` int(5) DEFAULT '0',
  `status` varchar(100) DEFAULT NULL,
  `picture` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

INSERT INTO teacher VALUES("2","3","Lalnunmawia","male","1985-11-09","Ramhlun","Aizawl","Lunglei","Lunglei North Sub Division","2012-01-03","Bachelor of Arts","Bachelor","Un-Trained","","None","First Language","This is the achievement","No","0","Regular","/uploads/teachers/2.jpg","1","2013-06-19 12:33:01","2013-07-20 20:48:11");
INSERT INTO teacher VALUES("3","3","Lalramliani","female","1985-11-09","Aizawl","Lunglei","Aizawl","Aizawl East Sub Division","2012-01-03","Bachelor of Arts","Bachelor","Un-Trained","","None","First Language","","No","0","Regular","/uploads/teachers/3.jpg","1","2013-06-19 12:57:34","2013-07-20 20:48:21");
INSERT INTO teacher VALUES("4","3","Zonunsangi","female","1985-11-09","Aizawl","Champhai","Aizawl","Aizawl East Sub Division","2012-01-03","Bachelor of Arts","Diploma","Un-Trained","","None","First Language","","No","0","Private","/uploads/teachers/4.jpg","1","2013-06-19 12:58:18","2013-07-20 20:49:29");
INSERT INTO teacher VALUES("5","5","Rinthanga","male","1985-11-09","C-95, Ramthar Tlangveng","Serchhip","Lunglei","Hnahthial Sub Division","2013-06-17","Bachelor of Arts","Bachelor","Un-Trained","2045","None","First Language","","No","2","Regular","/uploads/teachers/5.jpg","1","2013-06-19 13:30:15","2013-07-27 01:12:04");
INSERT INTO teacher VALUES("100","4","Lalrinliana","male","1985-11-09","College Veng","Aizawl","Lunglei","Hnahthial Sub Division","2012-01-03","Under Graduate","Bachelor","Trained","","None","First Language","","No","0","Regular","/uploads/teachers/6.jpg","1","2013-06-19 19:38:22","2013-07-20 20:49:08");
INSERT INTO teacher VALUES("101","6","Ramfangzauva","male","1980-07-23","Serkawn","Serchhip","Lunglei","Hnahthial Sub Division","2013-06-25","Master of Arts","Master","","","B","Science","","No","0","Non Regular","","1","2013-06-25 23:10:07","2013-06-25 23:24:46");
INSERT INTO teacher VALUES("102","5","Rinmuansanga","male","1985-11-09","Serkawn","Lunglei","Lunglei","Hnahthial Sub Division","2012-01-03","Bachelor of Arts","Master","None","","A","English","","No","0","Non Regular","","1","2013-06-28 17:44:36","2013-06-28 17:44:36");
INSERT INTO teacher VALUES("103","5","Lalhmuchhuaki","female","1985-11-09","Hetah","Khutah","Kolasib","Kolasib Block","2012-01-03","Bachelor of Arts","Master","Un-Trained","2045","A","First Language","None","No","0","Regular","","1","2013-07-20 20:42:37","2013-07-27 01:12:31");
INSERT INTO teacher VALUES("104","5","Thangliana","male","1985-11-09","asda","asdad","Champhai","Champhai Block","2012-01-03","Bachelor of Arts","Master","Un-Trained","2045","A","English","asdasd","No","0","Non Regular","","1","2013-07-22 19:12:23","2013-07-22 19:12:23");



DROP TABLE IF EXISTS training;

CREATE TABLE `training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `from` date DEFAULT NULL,
  `to` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO training VALUES("5","3","5","2013-06-27","2013-06-29","Completed","1","2013-06-19 23:32:29","2013-06-19 23:32:29");
INSERT INTO training VALUES("9","3","5","2013-06-20","2013-06-26","Active","1","2013-06-20 01:25:49","2013-06-20 01:25:49");



DROP TABLE IF EXISTS user;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `password_salt` varchar(200) DEFAULT NULL,
  `picture` varchar(400) DEFAULT NULL,
  `present_address` text,
  `permanent_address` text,
  `role` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `educational_qualification` varchar(200) DEFAULT NULL,
  `professional_qualification` varchar(200) DEFAULT NULL,
  `other_qualification` varchar(200) DEFAULT NULL,
  `loggedin_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO user VALUES("1","admin","Administrator","ede9ef6461373bc34a4f17f875da661f","kpnzWL|LU@Z=@ALr^9A?Gj+wo![;Q(0>","/uploads/users/1.jpg","Ramthar, Aizawl","","administrator","1978-01-01","9436542323","2012-01-03","Bachelor of Arts","History","","2013-08-14 11:25:25","2013-06-15 00:00:00","2013-06-26 00:38:31");
INSERT INTO user VALUES("2","john","John","28af274db5cd1628d34c773097b418d7","oHb<^K]x@E(SP8d)e9@l+Qsje-OMB\"!2","/uploads/users/2.jpg","Armed Veng","Aizawl","faculty","1985-11-09","9436542323","2012-01-03","Bachelor of Arts","History","","2013-07-22 19:29:43","2013-06-19 14:06:48","2013-07-20 17:23:09");
INSERT INTO user VALUES("3","peter","Peter","28af274db5cd1628d34c773097b418d7","oHb<^K]x@E(SP8d)e9@l+Qsje-OMB\"!2","/uploads/users/2.jpg","Armed Veng","Aizawl","faculty","1985-11-09","9436542323","2012-01-03","Bachelor of Arts","History","","2013-06-19 14:06:48","2013-06-19 14:06:48","2013-06-19 14:06:48");
INSERT INTO user VALUES("4","robert","Robert","28af274db5cd1628d34c773097b418d7","oHb<^K]x@E(SP8d)e9@l+Qsje-OMB\"!2","/uploads/users/2.jpg","Armed Veng","Aizawl","faculty","1985-11-09","9436542323","2012-01-03","Bachelor of Arts","History","","2013-06-19 14:06:48","2013-06-19 14:06:48","2013-06-19 14:06:48");
INSERT INTO user VALUES("5","ivan","Ivan","28af274db5cd1628d34c773097b418d7","oHb<^K]x@E(SP8d)e9@l+Qsje-OMB\"!2","/uploads/users/2.jpg","Armed Veng","Aizawl","faculty","1985-11-09","9436542323","2012-01-03","Bachelor of Arts","History","","2013-06-19 14:06:48","2013-06-19 14:06:48","2013-06-19 14:06:48");
INSERT INTO user VALUES("6","michael","Michael","28af274db5cd1628d34c773097b418d7","oHb<^K]x@E(SP8d)e9@l+Qsje-OMB\"!2","/uploads/users/2.jpg","Armed Veng","Aizawl","faculty","1985-11-09","9436542323","2012-01-03","Bachelor of Arts","History","","2013-06-19 14:06:48","2013-06-19 14:06:48","2013-06-19 14:06:48");
INSERT INTO user VALUES("7","alan","Alan Pachuau","28d3407ff277b4bd5c00d60c99ab8659","%qD!DQnCv|*bq<Xq*Nm\'^mVu|IR&W#L\\","/uploads/users/7.jpg","asd","Lunglei","user","2013-06-19","9436542323","2013-06-19","Bachelor of Arts","History","","2013-07-27 00:52:18","2013-06-19 23:36:52","2013-06-26 01:06:14");



