DROP TABLE IF EXISTS backup;

CREATE TABLE `backup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `file` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO backup VALUES("1","/uploads/backup/db-backup-1376589566.sql.gz","2013-08-15 23:29:26","2013-08-15 23:29:26");
INSERT INTO backup VALUES("2","/uploads/backup/db-backup-1376836188.sql.gz","2013-08-18 19:59:48","2013-08-18 19:59:48");



DROP TABLE IF EXISTS options;

CREATE TABLE `options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(400) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO options VALUES("1","diet_district","Aizawl");
INSERT INTO options VALUES("2","colors","#2FA3CF,#106383,#106383,#106383");
INSERT INTO options VALUES("3","logo","/uploads/logo/logo.jpg");



DROP TABLE IF EXISTS program;

CREATE TABLE `program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `program_date` datetime DEFAULT NULL,
  `duration` int(45) DEFAULT NULL,
  `target` varchar(200) DEFAULT NULL,
  `objectives` text,
  `no_of_intake` int(11) DEFAULT NULL,
  `faculties` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO program VALUES("1","Programme One","2013-03-12 00:00:00","10","Target One","asd","10","2","1","2013-08-18 21:04:40","2013-08-18 21:04:40");
INSERT INTO program VALUES("2","Programme 3","2009-02-02 00:00:00","20","asd","asd","10","2","1","2013-08-18 21:07:19","2013-08-18 21:07:19");
INSERT INTO program VALUES("3","Programme 4","2011-06-08 00:00:00","20","asd","asd","10","2","1","2013-08-18 21:07:19","2013-08-18 21:07:19");
INSERT INTO program VALUES("4","Programme 5","2012-10-20 00:00:00","20","asd","asd","10","2","1","2013-08-18 21:07:19","2013-08-18 21:07:19");
INSERT INTO program VALUES("5","My New Programme","2013-11-09 00:00:00","20","Target One","adasd","10","2","1","2013-08-18 23:54:28","2013-08-18 23:54:28");
INSERT INTO program VALUES("6","asd","2013-09-25 00:00:00","10","Target One","asd","10","2","1","2013-08-19 00:10:14","2013-08-19 00:10:14");



DROP TABLE IF EXISTS school;

CREATE TABLE `school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `address` text,
  `district` varchar(200) DEFAULT NULL,
  `sub_division` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `year_of_establishment` int(4) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL COMMENT 'Adhoc, Aided, Govt. etc.',
  `level` varchar(250) DEFAULT NULL,
  `no_of_teachers` int(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO school VALUES("1","Ramthar Government Primary School","Ramthar","Aizawl","Aizawl East Sub Division","1231231231","1987","Govt","Primary School","","1","2013-08-17 00:02:27","2013-08-17 00:02:27");
INSERT INTO school VALUES("2","Govt Middle School, Tlangnuam","Tlangnuam","Aizawl","Aizawl West Sub Division","9612800483","1975","Govt","Middle School","","1","2013-08-18 17:28:38","2013-08-18 17:28:38");
INSERT INTO school VALUES("3","Chanmari Government Primary School","Chanmari","Aizawl","Aizawl East Sub Division","1231231231","1987","Govt","Primary School","","1","2013-08-17 00:02:27","2013-08-17 00:02:27");



DROP TABLE IF EXISTS school_statistic;

CREATE TABLE `school_statistic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) NOT NULL,
  `teachers` int(6) DEFAULT NULL,
  `boys_pre` int(6) NOT NULL,
  `girls_pre` int(6) NOT NULL,
  `boys_1` int(6) NOT NULL,
  `girls_1` int(6) NOT NULL,
  `boys_2` int(6) NOT NULL,
  `girls_2` int(6) NOT NULL,
  `boys_3` int(6) NOT NULL,
  `girls_3` int(6) NOT NULL,
  `boys_4` int(6) NOT NULL,
  `girls_4` int(6) NOT NULL,
  `boys_5` int(6) NOT NULL,
  `girls_5` int(6) NOT NULL,
  `boys_6` int(6) NOT NULL,
  `girls_6` int(6) NOT NULL,
  `boys_7` int(6) NOT NULL,
  `girls_7` int(6) NOT NULL,
  `boys_8` int(6) NOT NULL,
  `girls_8` int(6) NOT NULL,
  `year` int(4) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO school_statistic VALUES("1","1","23","10","20","10","10","10","12","5","101","120","102","0","0","0","0","0","0","0","0","2013","2013-08-18 17:29:23","2013-08-18 17:33:59");
INSERT INTO school_statistic VALUES("2","2","200","0","0","0","0","0","0","0","0","0","0","90","100","11","12","45","14","150","160","2013","2013-08-18 17:43:01","2013-08-18 17:43:01");
INSERT INTO school_statistic VALUES("3","3","90","90","90","90","90","90","90","90","90","90","90","0","0","0","0","0","0","0","0","2013","2013-08-18 19:45:44","2013-08-18 19:45:44");



DROP TABLE IF EXISTS sub_division_block;

CREATE TABLE `sub_division_block` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `district` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO sub_division_block VALUES("1","Aizawl East Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("2","Aizawl West Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("3","Aizawl South Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("4","Lungsen Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("5","Darlawn Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("6","Saitual Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("7","Lunglei North Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("8","Lunglei South Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("9","Hnahthial Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("10","Serchhip Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("11","North Vanlaiphai Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("12","Thenzawl Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("13","Saiha Block","Saiha");
INSERT INTO sub_division_block VALUES("14","Tuipang Block","Saiha");
INSERT INTO sub_division_block VALUES("15","Bungtlang South Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("16","Sangau Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("17","Chawngte Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("18","Lawngtlai Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("19","Champhai Block","Champhai");
INSERT INTO sub_division_block VALUES("20","Khawbung Block","Champhai");
INSERT INTO sub_division_block VALUES("21","Khawzawl Block","Champhai");
INSERT INTO sub_division_block VALUES("22","Ngopa Block","Champhai");
INSERT INTO sub_division_block VALUES("23","Mamit Sub Division","Mamit");
INSERT INTO sub_division_block VALUES("24","Kawrthah Sub Division","Mamit");
INSERT INTO sub_division_block VALUES("25","West Phaileng Sub Division","Mamit");
INSERT INTO sub_division_block VALUES("26","Kolasib Block","Kolasib");
INSERT INTO sub_division_block VALUES("27","Kawnpui Block","Kolasib");



DROP TABLE IF EXISTS teacher;

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `sex` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(300) DEFAULT NULL,
  `present_address` text,
  `permanent_address` text,
  `district` varchar(200) DEFAULT NULL,
  `sub_division` varchar(200) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `educational_qualification` varchar(200) DEFAULT NULL,
  `professional_qualification` varchar(200) DEFAULT NULL,
  `other_qualification` varchar(45) DEFAULT NULL COMMENT 'Yes or No. Trained or Not trained.',
  `year_of_retirement` int(4) DEFAULT NULL,
  `tet` varchar(10) DEFAULT NULL COMMENT 'Teacher Eligibility Test',
  `main_subject_taught` varchar(200) DEFAULT NULL,
  `achievement` text,
  `training_attended` varchar(3) NOT NULL DEFAULT 'No',
  `no_of_training` int(5) DEFAULT '0',
  `status` varchar(100) DEFAULT NULL,
  `picture` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO teacher VALUES("1","1","Rinmawia","male","1985-11-09","9612800483","Present ad","asd","Aizawl","Aizawl East Sub Division","2012-01-03","Bachelor of Arts","Master","None","2045","A","English","asdasd","Yes","3","Non Regular","","1","2013-08-17 09:43:52","2013-08-17 09:43:52");
INSERT INTO teacher VALUES("2","3","Lalzirliana","male","1985-11-09","9612800483","asd","asd","Aizawl","Darlawn Sub Division","2012-01-03","Bachelor of Arts","Bachelor","Un-Trained","2045","A","English","asd","Yes","2","Regular","","1","2013-08-18 22:36:30","2013-08-18 22:36:30");
INSERT INTO teacher VALUES("3","2","Vanhnuaithanga","male","1985-11-09","9612800483","asd","asd","Aizawl","Darlawn Sub Division","2012-01-03","Bachelor of Arts","Bachelor","Un-Trained","2045","A","English","asd","Yes","5","Regular","","1","2013-08-18 22:36:30","2013-08-18 22:36:30");
INSERT INTO teacher VALUES("4","2","Lalramliani","female","1985-11-09","9612800483","asd","asd","Aizawl","Darlawn Sub Division","2012-01-03","Bachelor of Arts","Bachelor","Un-Trained","2045","A","English","asd","Yes","4","Regular","","1","2013-08-18 22:36:30","2013-08-18 22:36:30");
INSERT INTO teacher VALUES("5","2","Lalnunpuia","male","1985-11-09","9612800483","asd","asd","Aizawl","Aizawl West Sub Division","2012-01-03","Bachelor of Arts","Master","asd","2045","A","English","asd","Yes","2","Non Regular","","1","2013-08-18 23:16:36","2013-08-18 23:16:36");



DROP TABLE IF EXISTS training;

CREATE TABLE `training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `from` date DEFAULT NULL,
  `to` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO training VALUES("1","1","1","2010-08-18","2010-09-26","Active","1","2013-08-18 21:05:20","2013-08-18 21:05:20");
INSERT INTO training VALUES("2","1","3","2008-08-18","2008-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("3","3","2","2009-08-18","2009-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("4","2","1","2012-08-18","2012-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("5","4","4","2013-08-18","2013-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("6","5","2","2010-08-18","2010-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("7","1","3","2011-08-18","2011-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("8","3","3","2013-08-18","2013-09-30","Active","1","2013-08-18 21:07:36","2013-08-18 21:07:36");
INSERT INTO training VALUES("9","2","3","2013-11-18","2013-12-30","Active","1","2013-08-18 23:04:57","2013-08-18 23:04:57");
INSERT INTO training VALUES("10","4","4","2013-08-18","2013-08-19","Active","1","2013-08-18 23:05:19","2013-08-18 23:05:19");
INSERT INTO training VALUES("12","6","5","2013-09-20","2013-09-30","Active","1","2013-08-20 17:24:41","2013-08-20 17:24:41");
INSERT INTO training VALUES("14","3","4","2013-08-20","2013-09-28","Active","1","2013-08-20 17:26:50","2013-08-20 17:26:50");
INSERT INTO training VALUES("18","4","5","2013-08-20","2013-08-21","Active","1","2013-08-20 17:32:17","2013-08-20 17:32:17");
INSERT INTO training VALUES("19","5","4","2013-09-20","2013-08-21","Active","1","2013-08-20 17:32:42","2013-08-20 17:32:42");
INSERT INTO training VALUES("20","5","1","2013-08-20","2013-08-21","Active","1","2013-08-20 17:33:22","2013-08-20 17:33:22");
INSERT INTO training VALUES("21","4","3","2013-08-20","2013-08-21","Active","1","2013-08-20 17:33:37","2013-08-20 17:33:37");



DROP TABLE IF EXISTS user;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `password_salt` varchar(200) DEFAULT NULL,
  `picture` varchar(400) DEFAULT NULL,
  `present_address` text,
  `permanent_address` text,
  `role` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `educational_qualification` varchar(200) DEFAULT NULL,
  `professional_qualification` varchar(200) DEFAULT NULL,
  `other_qualification` varchar(200) DEFAULT NULL,
  `loggedin_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO user VALUES("1","admin","Administrator","ede9ef6461373bc34a4f17f875da661f","kpnzWL|LU@Z=@ALr^9A?Gj+wo![;Q(0>","/uploads/users/1.jpg","Ramthar, Aizawl","","administrator","1978-01-01","9436542323","2012-01-03","Bachelor of Arts","History","","2013-08-20 22:33:34","2013-06-15 00:00:00","2013-06-26 00:38:31");
INSERT INTO user VALUES("2","liana","Liana","e107bda395082d4204ae7818cb49ad95","g&/q^0{xXCY7Ev<S+r2{`\'(JB!&Ie~EM","","asd","asd","faculty","1985-11-09","9612800483","2012-01-03","Bachelor of Arts","Master","adasd","2013-08-18 21:03:17","2013-08-18 21:03:17","2013-08-18 21:04:25");
INSERT INTO user VALUES("3","guest","Guest","b7b0c2fdf988469b08d8f1dd8ae76dee","^E&beChC>+qw66Y8Yz6PS2HP+MlN};w\\","","asd","asd","user","1985-11-09","9436542329","2012-01-03","Bachelor of Arts","Master","Un-Trained","2013-08-20 18:49:29","2013-08-20 18:49:21","2013-08-20 18:49:21");



