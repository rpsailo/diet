DROP TABLE IF EXISTS backup;

CREATE TABLE `backup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `file` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS options;

CREATE TABLE `options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(400) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO options VALUES("1","diet_district","Aizawl");
INSERT INTO options VALUES("2","colors","");



DROP TABLE IF EXISTS program;

CREATE TABLE `program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `duration` int(45) DEFAULT NULL,
  `target` varchar(200) DEFAULT NULL,
  `objectives` text,
  `no_of_intake` int(11) DEFAULT NULL,
  `faculties` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS school;

CREATE TABLE `school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `address` text,
  `district` varchar(200) DEFAULT NULL,
  `sub_division` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `year_of_establishment` int(4) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL COMMENT 'Adhoc, Aided, Govt. etc.',
  `level` varchar(250) DEFAULT NULL,
  `no_of_teachers` int(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS school_statistic;

CREATE TABLE `school_statistic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` int(10) NOT NULL,
  `teachers` int(6) DEFAULT NULL,
  `boys_1` int(6) NOT NULL,
  `girls_1` int(6) NOT NULL,
  `boys_2` int(6) NOT NULL,
  `girls_2` int(6) NOT NULL,
  `boys_3` int(6) NOT NULL,
  `girls_3` int(6) NOT NULL,
  `boys_4` int(6) NOT NULL,
  `girls_4` int(6) NOT NULL,
  `boys_5` int(6) NOT NULL,
  `girls_5` int(6) NOT NULL,
  `boys_6` int(6) NOT NULL,
  `girls_6` int(6) NOT NULL,
  `boys_7` int(6) NOT NULL,
  `girls_7` int(6) NOT NULL,
  `boys_8` int(6) NOT NULL,
  `girls_8` int(6) NOT NULL,
  `year` int(4) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS sub_division_block;

CREATE TABLE `sub_division_block` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `district` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO sub_division_block VALUES("1","Aizawl East Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("2","Aizawl West Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("3","Aizawl South Sub Division","Aizawl");
INSERT INTO sub_division_block VALUES("4","Lungsen Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("5","Darlawn Sub Division","");
INSERT INTO sub_division_block VALUES("6","Saitual Sub Division","");
INSERT INTO sub_division_block VALUES("7","Lunglei North Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("8","Lunglei South Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("9","Hnahthial Sub Division","Lunglei");
INSERT INTO sub_division_block VALUES("10","Serchhip Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("11","North Vanlaiphai Sub Division","Serchhip");
INSERT INTO sub_division_block VALUES("12","Thenzawl Sub Division","");
INSERT INTO sub_division_block VALUES("13","Saiha Block","Saiha");
INSERT INTO sub_division_block VALUES("14","Tuipang Block","Serchhip");
INSERT INTO sub_division_block VALUES("15","Bungtlang South Block","");
INSERT INTO sub_division_block VALUES("16","Sangau Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("17","Chawngte Block","");
INSERT INTO sub_division_block VALUES("18","Bualpui N  Sub Division","");
INSERT INTO sub_division_block VALUES("19","Lawngtlai Block","Lawngtlai");
INSERT INTO sub_division_block VALUES("20","Champhai Block","Champhai");
INSERT INTO sub_division_block VALUES("21","Khawbung Block","");
INSERT INTO sub_division_block VALUES("22","Khawzawl Block","");
INSERT INTO sub_division_block VALUES("23","Ngopa Block","Champhai");
INSERT INTO sub_division_block VALUES("24","Mamit Sub Division","Mamit");
INSERT INTO sub_division_block VALUES("25","Kawrthah Sub Division","");
INSERT INTO sub_division_block VALUES("26","West Phaileng Sub Division","");
INSERT INTO sub_division_block VALUES("27","Kolasib Block","Kolasib");
INSERT INTO sub_division_block VALUES("28","Kawnpui Block","");



DROP TABLE IF EXISTS teacher;

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `sex` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `present_address` text,
  `permanent_address` text,
  `district` varchar(200) DEFAULT NULL,
  `sub_division` varchar(200) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `educational_qualification` varchar(200) DEFAULT NULL,
  `professional_qualification` varchar(200) DEFAULT NULL,
  `other_qualification` varchar(45) DEFAULT NULL COMMENT 'Yes or No. Trained or Not trained.',
  `year_of_retirement` int(4) DEFAULT NULL,
  `tet` varchar(10) DEFAULT NULL COMMENT 'Teacher Eligibility Test',
  `main_subject_taught` varchar(200) DEFAULT NULL,
  `achievement` text,
  `training_attended` varchar(3) NOT NULL DEFAULT 'No',
  `no_of_training` int(5) DEFAULT '0',
  `status` varchar(100) DEFAULT NULL,
  `picture` varchar(400) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS training;

CREATE TABLE `training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `from` date DEFAULT NULL,
  `to` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS user;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `password_salt` varchar(200) DEFAULT NULL,
  `picture` varchar(400) DEFAULT NULL,
  `present_address` text,
  `permanent_address` text,
  `role` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `educational_qualification` varchar(200) DEFAULT NULL,
  `professional_qualification` varchar(200) DEFAULT NULL,
  `other_qualification` varchar(200) DEFAULT NULL,
  `loggedin_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO user VALUES("1","admin","Administrator","ede9ef6461373bc34a4f17f875da661f","kpnzWL|LU@Z=@ALr^9A?Gj+wo![;Q(0>","/uploads/users/1.jpg","Ramthar, Aizawl","","administrator","1978-01-01","9436542323","2012-01-03","Bachelor of Arts","History","","2013-08-15 21:41:55","2013-06-15 00:00:00","2013-06-26 00:38:31");



